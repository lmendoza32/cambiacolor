package com.example.cambiacolor

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var view: View
    private lateinit var button:FloatingActionButton
    private val colores = arrayOf(Color.RED, Color.WHITE, Color.GRAY, Color.GREEN, Color.MAGENTA, Color.YELLOW)

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        view = findViewById(R.id.view)
        button = findViewById(com.google.android.material.R.id.floating)

        button.setOnClickListener {
            view.setBackgroundColor(colores[Random.nextInt(colores.size)])
        }
    }
}